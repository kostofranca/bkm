char* itoa(int value, char* buffer, int base);
unsigned char hex_uppercase(unsigned char ptr);
int hexasc2num(char *ptr,int len);
void convert2asc(unsigned int num, char *str, int width, int radix);
