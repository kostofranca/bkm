#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "setup.h"
#include "gps.h"

void main(void)
{
	printf("hello World!\n");
}
