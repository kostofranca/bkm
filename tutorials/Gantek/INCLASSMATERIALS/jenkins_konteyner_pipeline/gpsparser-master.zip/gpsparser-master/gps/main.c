#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "setup.h"
#include "gps.h"

int main(void)
{
	printf("deneme1-2\n");
	return 1;
}
