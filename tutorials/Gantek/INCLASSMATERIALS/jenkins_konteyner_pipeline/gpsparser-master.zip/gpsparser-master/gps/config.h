#ifndef _CONFIG_H_
#define _CONFIG_H_

#define TRUE				 1
#define FALSE				 0

#define BOOL				int 

#endif
